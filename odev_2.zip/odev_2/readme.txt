Bu Zip dosyası WEKA platformunda eğitilmiş 5 farklı modelin model dosyalarını, veri setlerini parametrelerini ve sonuçlarını içermektedir. Tekrar oluşturulabilmesi için kolaylıkla model dosyalarının kolaylıkla WEKA platformu ile erişilebilirliği sağlanmıştır. Aynı zamanda izlenen yöntemleri ve sonuçları içeren bir pdf dosyası da mevcuttur.
 
Modeller: 
- Naive Bayes Sınıflandırıcı 
- K-ortalamalı Öbekleyici 
- K-NN Sınıflandırıcı
- AdaBoost Sınıflandırıcı 
- RandomForest Sınıflandırıcı

